#!/bin/bash
make;
cd /home/mahiru/oslab/lab3-alloc/trace/;
./run.sh