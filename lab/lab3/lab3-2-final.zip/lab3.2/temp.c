   if(ktest_func == 4){
        while(temp_data < end_data){
            vma = find_vma(mm, temp_data);

            for(addr = vma->vm_start; addr < vma->vm_end - PAGE_SIZE; addr = addr + PAGE_SIZE){
                struct page *page = mfollow_page(vma, addr, FOLL_GET);
                if(IS_ERR_OR_NULL(page) != 0){
                    continue;
                }
                virt_addr = kmap_atomic(page);
                kunmap_atomic(virt_addr);

                unsigned long page_start = addr;
                unsigned long page_end = addr + PAGE_SIZE;
                unsigned long offset;
                unsigned long addr_offset;

                if(!(page_start > end_data || page_end < start_code)){
                    addr_offset = (start_code >= page_start) ? (virt_addr + (start_code - page_start)) : virt_addr;
                    offset = min(page_end,end_data) - max(page_start,start_code);
                    memcpy(buf,addr_offset,offset);
                    kernel_write(log_file, (char *)buf, offset, &log_file->f_pos);               
                }
            }
            temp_data += PAGE_SIZE;
        }
   }
   //mmput(mm);
}