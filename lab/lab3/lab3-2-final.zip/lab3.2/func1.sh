#!/bin/bash
sudo dmesg -C;
sudo ./run_expr.sh 5;
#cat /sys/kernel/mm/ktest/vma;